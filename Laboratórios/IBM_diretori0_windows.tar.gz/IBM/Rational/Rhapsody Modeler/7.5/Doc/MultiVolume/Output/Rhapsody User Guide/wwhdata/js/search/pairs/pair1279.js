function FileData_Pairs(x)
{
x.t("diagrams","composite");
x.t("creating","composite");
x.t("composite","classes");
x.t("detailed","information");
x.t("information","composite");
x.t("structure","diagrams");
x.t("classes","creating");
x.t("classes","composite");
x.t("classes","detailed");
x.t("classes","structure");
x.t("classes","object");
x.t("model","diagrams");
x.t("object","model");
}
