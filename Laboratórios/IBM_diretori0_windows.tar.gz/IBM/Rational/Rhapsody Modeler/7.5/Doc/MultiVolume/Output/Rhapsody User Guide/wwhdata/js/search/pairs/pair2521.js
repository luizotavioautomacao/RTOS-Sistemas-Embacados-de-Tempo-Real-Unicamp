function FileData_Pairs(x)
{
x.t("functional","requirements");
x.t("describes","system's");
x.t("rational","rhapsody");
x.t("requirements","terms");
x.t("glossary","case");
x.t("rhapsody","glossary");
x.t("system's","functional");
x.t("case","model");
x.t("model","describes");
x.t("model","rational");
x.t("model","case");
x.t("model","model");
x.t("terms","cases");
}
