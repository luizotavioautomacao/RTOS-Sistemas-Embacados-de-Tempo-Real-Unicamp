// Copyright (c) 2000-2005 Quadralay Corporation.  All rights reserved.
//

// Increment book index
//
WWHFrame.WWHSearch.mCombinedResultsIndex++;
