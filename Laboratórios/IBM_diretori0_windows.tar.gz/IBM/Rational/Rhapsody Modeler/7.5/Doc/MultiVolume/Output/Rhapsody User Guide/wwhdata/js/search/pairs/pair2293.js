function FileData_Pairs(x)
{
x.t("interrupts","running");
x.t("instance","deleted");
x.t("breakpoint","condition");
x.t("rational","rhapsody");
x.t("glossary","instance");
x.t("rhapsody","glossary");
x.t("running","application");
x.t("condition","interrupts");
x.t("condition","instance");
x.t("condition","rational");
x.t("application","object");
x.t("deleted","breakpoint");
x.t("object","deleted");
}
