function FileData_Pairs(x)
{
x.t("tracing","tracing");
x.t("tracing","displays");
x.t("tracing","rational");
x.t("program","execution");
x.t("displays","trace");
x.t("trace","messages");
x.t("during","program");
x.t("rational","rhapsody");
x.t("glossary","tracing");
x.t("messages","during");
x.t("rhapsody","glossary");
}
