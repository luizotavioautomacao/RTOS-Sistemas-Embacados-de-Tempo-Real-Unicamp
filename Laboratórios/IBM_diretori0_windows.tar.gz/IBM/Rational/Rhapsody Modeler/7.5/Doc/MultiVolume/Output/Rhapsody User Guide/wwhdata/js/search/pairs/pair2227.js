function FileData_Pairs(x)
{
x.t("example","source");
x.t("source","target");
x.t("rational","rhapsody");
x.t("direction","example");
x.t("glossary","directional");
x.t("exists","direction");
x.t("relation","rational");
x.t("relation","exists");
x.t("relation","relation");
x.t("relation","directional");
x.t("rhapsody","glossary");
x.t("directional","relation");
}
