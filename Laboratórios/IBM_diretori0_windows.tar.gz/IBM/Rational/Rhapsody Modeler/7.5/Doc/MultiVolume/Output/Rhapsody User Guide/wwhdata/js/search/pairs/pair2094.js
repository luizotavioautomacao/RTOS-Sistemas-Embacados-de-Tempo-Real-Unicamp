function FileData_Pairs(x)
{
x.t("support","ibm");
x.t("support","technical");
x.t("support","resources");
x.t("rational","rhapsody");
x.t("rational","software");
x.t("ibm","rational");
x.t("rhapsody","customers");
x.t("receive","support");
x.t("software","support");
x.t("customers","receive");
x.t("technical","support");
}
