function FileData_Pairs(x)
{
x.t("integration","generate");
x.t("rational","rhapsody");
x.t("edit","rational");
x.t("edit","code");
x.t("rhapsody","code");
x.t("code","edit");
x.t("code","eclipse");
x.t("code","using");
x.t("generate","edit");
x.t("eclipse","editor");
x.t("eclipse","platform");
x.t("platform","integration");
x.t("using","eclipse");
}
