// Copyright (c) 2001-2003 Quadralay Corporation.  All rights reserved.
//

function  WWHBookGroups_Books(ParamTop)
{


  ParamTop.fAddDirectory("Notices", null, null, null, null);
  ParamTop.fAddDirectory("Modeler Tutorial", null, null, null, null);
  ParamTop.fAddDirectory("Getting Started Guide", null, null, null, null);
  ParamTop.fAddDirectory("Rhapsody User Guide", null, null, null, null);
  ParamTop.fAddDirectory("Team Collaboration Guide", null, null, null, null);
}

function  WWHBookGroups_ShowBooks()
{
  return true;
}

function  WWHBookGroups_ExpandAllAtTop()
{
  return false;
}
