// Copyright (c) 2001-2003 Quadralay Corporation.  All rights reserved.
//

function  WWHBookGroups_Books(ParamTop)
{


  ParamTop.fAddDirectory(".", null, null, null, null);
}

function  WWHBookGroups_ShowBooks()
{
  return false;
}

function  WWHBookGroups_ExpandAllAtTop()
{
  return false;
}
