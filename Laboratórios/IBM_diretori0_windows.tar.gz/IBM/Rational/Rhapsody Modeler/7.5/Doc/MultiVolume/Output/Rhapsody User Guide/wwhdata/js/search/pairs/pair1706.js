function FileData_Pairs(x)
{
x.t("tracing","tracer");
x.t("description","tracer");
x.t("description","help");
x.t("tracer","commands");
x.t("displays","brief");
x.t("command","displays");
x.t("commands","syntax");
x.t("commands","help");
x.t("syntax","help");
x.t("brief","description");
x.t("help","tracing");
x.t("help","description");
x.t("help","command");
x.t("help","help");
}
