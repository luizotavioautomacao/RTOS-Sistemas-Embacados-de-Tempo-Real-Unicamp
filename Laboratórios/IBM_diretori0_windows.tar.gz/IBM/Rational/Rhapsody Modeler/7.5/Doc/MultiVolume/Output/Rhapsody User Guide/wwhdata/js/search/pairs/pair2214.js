function FileData_Pairs(x)
{
x.t("derived","class");
x.t("rational","rhapsody");
x.t("base","class");
x.t("glossary","derived");
x.t("functions","base");
x.t("rhapsody","glossary");
x.t("inherits","data");
x.t("data","member");
x.t("class","derived");
x.t("class","(subclass)");
x.t("class","rational");
x.t("class","inherits");
x.t("class","class");
x.t("member","functions");
}
