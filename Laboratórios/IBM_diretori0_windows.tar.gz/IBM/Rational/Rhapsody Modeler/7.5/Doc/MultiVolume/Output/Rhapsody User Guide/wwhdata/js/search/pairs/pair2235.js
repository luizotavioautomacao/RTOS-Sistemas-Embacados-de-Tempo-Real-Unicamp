function FileData_Pairs(x)
{
x.t("element","element");
x.t("element","rational");
x.t("element","atomic");
x.t("rational","rhapsody");
x.t("glossary","element");
x.t("constituent","model");
x.t("rhapsody","glossary");
x.t("primary","model");
x.t("atomic","constituent");
x.t("model","primary");
x.t("model","elements");
}
