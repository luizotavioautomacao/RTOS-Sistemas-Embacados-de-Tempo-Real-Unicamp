function FileData_Pairs(x)
{
x.t("lists","groups");
x.t("support","comparison");
x.t("multiple","projects");
x.t("limitations","diffmerge");
x.t("rational","rhapsody");
x.t("comparison","project");
x.t("rhapsody","projects");
x.t("diffmerge","support");
x.t("diffmerge","rational");
x.t("diffmerge","diffmerge");
x.t("groups","projects");
x.t("projects","multiple");
x.t("projects","project");
x.t("project","lists");
x.t("project","limitations");
}
