function FileData_Pairs(x)
{
x.t("5.0","models");
x.t("introduced","java");
x.t("rational","rhapsody");
x.t("allows","include");
x.t("rhapsody","allows");
x.t("types","java");
x.t("java","5.0");
x.t("java","enums");
x.t("enums","introduced");
x.t("enums","rational");
x.t("enums","java");
x.t("enums","classes");
x.t("include","java");
x.t("classes","types");
}
