function FileData_Pairs(x)
{
x.t("public","inheritance");
x.t("inheritance","public");
x.t("inheritance","rational");
x.t("inheritance","subclass");
x.t("rational","rhapsody");
x.t("glossary","public");
x.t("rhapsody","glossary");
x.t("inherits","attributes");
x.t("subclass","inherits");
x.t("operations","superclass");
x.t("attributes","operations");
}
