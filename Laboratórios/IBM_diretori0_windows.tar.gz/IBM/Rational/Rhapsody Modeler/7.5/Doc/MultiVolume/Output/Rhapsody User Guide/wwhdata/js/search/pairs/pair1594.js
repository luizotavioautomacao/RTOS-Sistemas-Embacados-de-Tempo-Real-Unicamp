function FileData_Pairs(x)
{
x.t("diagrams","code");
x.t("mode","diagrams");
x.t("mode","code");
x.t("working","code-centric");
x.t("activity","diagrams");
x.t("code","generated");
x.t("code","generation");
x.t("statecharts","activity");
x.t("generated","diagrams");
x.t("generated","working");
x.t("generated","statecharts");
x.t("generated","code-centric");
x.t("generation","code-centric");
x.t("code-centric","mode");
}
